library(tidyverse)
library(lattice)
library(stringr)
select=dplyr::select
filter=dplyr::filter
summarise=dplyr::summarise
setwd("F:/OneDrive - zju.edu.cn/RAPSIM/Course7")

Scenarios=read.csv("ScenariosManage.csv")
Outfiles=list.files('./NewAPSIM',pattern = '.out$',full.names = T)


Simdata=readLines(Outfiles[1])
HeadName=grep("Date",Simdata,value = T)%>%str_trim()%>%str_split(.,'\\s+')%>%unlist()

Simdata=read.table(textConnection(Simdata[(grep("Date",Simdata)+2):length(Simdata)]),header = F,
                   stringsAsFactors = FALSE)

colnames(Simdata)=HeadName

Simdata$Date=as.Date(Simdata$Date,format = '%d/%m/%Y')

ggplot(Simdata,aes(x=Date,y=biomass))+
  geom_line()


