library(apsimx)
library(tidyverse)
library(BayesianTools)
library(rstantools)

############
# Classic
setwd('E:/APSIM/OPTIM')
wheat=apsim('Wheat.apsim')
obsWh=read.csv('E:/APSIM/OPTIM/ObsW.csv')%>%mutate(Date=as.Date(Date))
#Phe
ggplot() + 
  geom_point(data = obsWh, aes(x = Date, y = Stage)) +
  geom_line(data = wheat, aes(x = Date, y = Stage)) + 
  ggtitle("Phenology")

## LAI
ggplot() + 
  geom_point(data = obsWh, aes(x = Date, y = lai)) +
  geom_line(data = wheat, aes(x = Date, y = lai)) + 
  ggtitle("LAI")

## Biomass
ggplot() + 
  geom_point(data = obsWh, aes(x = Date, y = biomass)) +
  geom_line(data = wheat, aes(x = Date, y = biomass)) + 
  ggtitle("Biomass (g/m2)")



ObsSim=wheat%>%filter(Date%in%obsWh$Date)%>%
  select(Date,Stage,biomass,lai)%>%left_join(obsWh,.,by='Date')

ObsSim%>%ggplot(aes(x=lai.x,y=lai.y))+
  geom_point(size=2)+
  scale_x_continuous(limits = c(0,3.5))+
  scale_y_continuous(limits = c(0,3.5))+
  geom_smooth(method = 'lm',se = FALSE)+
  geom_abline(slope = 1,intercept = 0,size=1,linetype=2,color='grey')+
  coord_equal()+
  theme_bw()
  
ObsSim%>%ggplot(aes(x=biomass.x,y=biomass.y))+
  geom_point(size=2)+
  scale_x_continuous(limits = c(0,10000))+
  scale_y_continuous(limits = c(0,10000))+
  geom_smooth(method = 'lm',se = FALSE)+
  geom_abline(slope = 1,intercept = 0,size=1,linetype=2,color='grey')+
  coord_equal()+
  theme_bw()

RMSEFun=function(simvalue,obsvalue) {sqrt(mean((simvalue-obsvalue)^2))}
RRMSEFun=function(simvalue,obsvalue) {sqrt(mean((simvalue-obsvalue)^2))/mean(obsvalue)}
EFFun=function(simvalue,obsvalue){
  1-sum((simvalue-obsvalue)^2)/sum((obsvalue-mean(obsvalue))^2)
}
DvalueFun=function(simvalue,obsvalue){1-sum((simvalue-obsvalue)^2)/sum((abs(simvalue-mean(obsvalue))+abs(obsvalue-mean(simvalue)))^2)}
MBEFun=function(simvalue,obsvalue){mean(abs(simvalue-obsvalue))}
R2Fun=function(simvalue,obsvalue){summary(lm(simvalue~1+obsvalue))$r.squared}
R2Funadj=function(simvalue,obsvalue){summary(lm(simvalue~1+obsvalue))$adj.r.squared}

ObsSim%>%dplyr::summarise(
  RMSE.biomass=RMSEFun(biomass.y,biomass.x),
  RRMSE.biomass=RRMSEFun(biomass.y,biomass.x),
  Dvalue.biomass=DvalueFun(biomass.y,biomass.x),
  EF.biomass=EFFun(biomass.y,biomass.x),
  RMSE.lai=RMSEFun(lai.y,lai.x),
  RRMSE.lai=RRMSEFun(lai.y,lai.x),
  Dvalue.lai=DvalueFun(lai.y,lai.x),
  EF.lai=EFFun(lai.y,lai.x)
)



#######调参
##调参rue
rue <- paste(c(0,0,1.2,1.2,1.2,1.2,1.2,1.2,0.00,0.00,0),collapse = "  ")
edit_apsim_xml("Wheat.xml", 
            src.dir = 'E:/APSIM/OPTIM',
            wrt.dir = './New',
            parm.path = ".//Model/plant/y_rue",
            value = rue)


##调参生育期
tt_end_of_juvenile='500'
edit_apsim_xml("Wheat.xml", 
               src.dir = 'E:/APSIM/OPTIM',
               wrt.dir = './New',
               parm.path = ".//Model/xifeng24/tt_end_of_juvenile",
               value = tt_end_of_juvenile)



wheat=apsim('Wheat.apsim')
#Phe
ggplot() + 
  geom_point(data = obsWh, aes(x = Date, y = Stage)) +
  geom_line(data = wheat, aes(x = Date, y = Stage)) + 
  ggtitle("Phenology")

## LAI
ggplot() + 
  geom_point(data = obsWh, aes(x = Date, y = lai)) +
  geom_line(data = wheat, aes(x = Date, y = lai)) + 
  ggtitle("LAI")

## Biomass
ggplot() + 
  geom_point(data = obsWh, aes(x = Date, y = biomass)) +
  geom_line(data = wheat, aes(x = Date, y = biomass)) + 
  ggtitle("Biomass (g/m2)")


ObjectFun=function(par){
  tt_end_of_juvenile=as.character(par)
  edit_apsim_xml("Wheat.xml", 
                 src.dir = 'E:/APSIM/OPTIM',
                 wrt.dir = './New',
                 parm.path = ".//Model/xifeng24/tt_end_of_juvenile",
                 value = tt_end_of_juvenile)
  
  wheat=apsim('Wheat.apsim')
  
  ObsSim=wheat%>%filter(Date%in%obsWh$Date)%>%
    select(Date,Stage,biomass,lai)%>%left_join(obsWh,.,by='Date')
  
  ModelRes=RRMSEFun(ObsSim$Stage.y,ObsSim$Stage.x)
  return(ModelRes)
}

Parsopt=optim(450, ObjectFun, method="Nelder-Mead")
ObjectFun(450)
ObjectFun(Parsopt$par)
edit_apsim_xml("Wheat.xml", 
               src.dir = 'E:/APSIM/OPTIM',
               wrt.dir = './New',
               parm.path = ".//Model/xifeng24/tt_end_of_juvenile",
               value = Parsopt$par%>%as.character())

wheat=apsim('Wheat.apsim')

ggplot() + 
  geom_point(data = obsWh, aes(x = Date, y = Stage)) +
  geom_line(data = wheat, aes(x = Date, y = Stage)) + 
  ggtitle("Phenology")


#########################################
# MCMC
##1 Likelihood
likelihood=function(pars=c(500,1.2,100)){

  edit_apsim_xml("Wheat.xml", 
                 src.dir = 'E:/APSIM/OPTIM',
                 wrt.dir = './New',
                 parm.path = ".//Model/xifeng24/tt_end_of_juvenile",
                 value = pars[1]%>%as.character())
  rue <- paste(c(0,0,rep(pars[2],6),0.00,0.00,0),collapse = "  ")
  edit_apsim_xml("Wheat-edited.xml", 
                 src.dir = './New',
                 wrt.dir = './New',
                 parm.path = ".//Model/plant/y_rue",
                 edit.tag ='',
                 value = rue)
  wheat=apsim('Wheat2.apsim')
  
  ObsSim=wheat%>%filter(Date%in%obsWh$Date)%>%
    select(Date,Stage,biomass,lai)%>%left_join(obsWh,.,by='Date')
  
  singlelikelihoods = dnorm(ObsSim$biomass.x, 
                            mean = ObsSim$biomass.y, 
                            sd =pars[3], log = T)
  sumll = sum(singlelikelihoods)
  
  return(sumll)
}

##2 更新参数
UpdatePar = function(pars=c(500,1.2,100)){
  return(rnorm(3,mean = pars, sd= c(10,0.1,10)))
}

##3 run MCMC
run_metropolis_MCMC = function(startvalue=c(500,1.25,100), iterations=1000){
  chain = array(dim = c(iterations+1,3))
  chain[1,] = startvalue
  for (i in 1:iterations){
    #1更新参数
    NewPars = UpdatePar(chain[i,]) 
    
    #2求后验概率或似然函数
    NewPost=likelihood(NewPars)
    OldPost=likelihood(chain[i,])
    
    ComparePost = exp(NewPost - OldPost) 
    #4如果比较值大于runif(1)则接受
    if (ComparePost>runif(1)){
      chain[i+1,] = NewPars
    }else{
      chain[i+1,] = chain[i,]
    }
    print(paste0('-----',i,'--------'))
  }
  return(chain)
}

startvalue = c(500,1.2,100)
iterations= 100
chain = run_metropolis_MCMC(startvalue, 100)

burnIn=10
par(mfrow = c(2,3))
hist(chain[-(1:burnIn),1],nclass=30,  main="Posterior of par1", xlab="True value = red line" )
abline(v = mean(chain[-(1:burnIn),1]))
abline(v = par[1], col="red" )
hist(chain[-(1:burnIn),2],nclass=30, main="Posterior of par2", xlab="True value = red line")
abline(v = mean(chain[-(1:burnIn),2]))
abline(v = par[2], col="red" )
hist(chain[-(1:burnIn),3],nclass=30, main="Posterior of par3", xlab="True value = red line")
abline(v = mean(chain[-(1:burnIn),3]) )
abline(v = par[3], col="red" )
plot(chain[-(1:burnIn),1], type = "l", xlab="True value = red line" , main = "Chain values of par1")
abline(h = par[1], col="red" )
plot(chain[-(1:burnIn),2], type = "l", xlab="True value = red line" , main = "Chain values of par2" )
abline(h = par[2], col="red" )
plot(chain[-(1:burnIn),3], type = "l", xlab="True value = red line" , main = "Chain values of par3")
abline(h = par[3], col="red" )

par1=mean(chain[-(1:burnIn),1])
par2=mean(chain[-(1:burnIn),2])

edit_apsim_xml("Wheat.xml", 
               src.dir = 'E:/APSIM/OPTIM',
               wrt.dir = './New',
               parm.path = ".//Model/xifeng24/tt_end_of_juvenile",
               value = par1%>%as.character())
rue <- paste(c(0,0,rep(par2,6),0.00,0.00,0),collapse = "  ")
edit_apsim_xml("Wheat-edited.xml", 
               src.dir = './New',
               wrt.dir = './New',
               parm.path = ".//Model/plant/y_rue",
               edit.tag ='',
               value = rue)
wheat=apsim('Wheat2.apsim')
wheat=apsim('Wheat.apsim')
ObsSim=wheat%>%filter(Date%in%obsWh$Date)%>%
  select(Date,Stage,biomass,lai)%>%left_join(obsWh,.,by='Date')

## Biomass
ggplot() + 
  geom_point(data = obsWh, aes(x = Date, y = biomass)) +
  geom_line(data = wheat, aes(x = Date, y = biomass)) + 
  ggtitle("Biomass (g/m2)")



############################################
#APSIM NG
library(apsimx)
library(tidyverse)
extd.dir <- system.file("extdata", package = "apsimx")
setwd('E:/APSIM/OPTIM')
obsWheat=read.csv('E:/APSIM/OPTIM/ObsWNG.csv')%>%mutate(Date=as.Date(Date))
head(obsWheat)
str(obsWheat)


sim0 <- apsimx("Wheat2.apsimx", src.dir = extd.dir)  
ggplot(sim0, aes(Date, Wheat.AboveGround.Wt)) + 
  geom_line(size=1) +
  ggtitle("Phenology Stages")


sim0.s <- sim0%>%filter(Date > as.Date("2016-09-30") & Date < as.Date("2017-07-01"))

#Phe
ggplot() + 
  geom_point(data = obsWheat, aes(x = Date, y = Wheat.Phenology.Stage)) +
  geom_line(data = sim0.s, aes(x = Date, y = Wheat.Phenology.Stage)) + 
  ggtitle("Phenology")


## LAI
ggplot() + 
  geom_point(data = obsWheat, aes(x = Date, y = Wheat.Leaf.LAI)) +
  geom_line(data = sim0.s, aes(x = Date, y = Wheat.Leaf.LAI)) + 
  ggtitle("LAI")

## Biomass
ggplot() + 
  geom_point(data = obsWheat, aes(x = Date, y = Wheat.AboveGround.Wt)) +
  geom_line(data = sim0.s, aes(x = Date, y = Wheat.AboveGround.Wt)) + 
  ggtitle("Biomass (g/m2)")


## Finding RUE
inspect_apsimx_replacement("Wheat-opt-ex.apsimx", 
                           src.dir = extd.dir,
                           node = "Wheat", 
                           node.child = "Leaf",
                           node.subchild = "Photosynthesis",
                           node.subsubchild = "RUE", 
                           parm = "FixedValue",
                           verbose = FALSE)

## Finding BasePhyllochron
inspect_apsimx_replacement("Wheat-opt-ex.apsimx", 
                           src.dir = extd.dir,
                           node = "Wheat", 
                           node.child = "Cultivars",
                           node.subchild = "USA",
                           node.subsubchild = "Yecora", 
                           verbose = FALSE)

pp1 <- "Wheat.Leaf.Photosynthesis.RUE.FixedValue"
pp2 <- "Wheat.Cultivars.USA.Yecora.BasePhyllochron"


###
wop <- optim_apsimx("Wheat-opt-ex.apsimx", 
                    src.dir = extd.dir, 
                    parm.paths = c(pp1, pp2),
                    data = obsWheat, 
                    weights = "mean",
                    replacement = c(TRUE, TRUE),
                    initial.values = c(1.2, 120),
                    hessian = TRUE)


sim.opt <- apsimx("Wheat-opt-ex.apsimx", src.dir = extd.dir, value = "report")  
sim.opt.s <- sim.opt%>%filter(Date > as.Date("2016-09-30") & Date < as.Date("2017-07-01"))

## phenology
ggplot() + 
  geom_point(data = obsWheat, aes(x = Date, y = Wheat.Phenology.Stage)) +
  geom_line(data = sim.opt.s, aes(x = Date, y = Wheat.Phenology.Stage)) + 
  ggtitle("Phenology")


## LAI
ggplot() + 
  geom_point(data = obsWheat, aes(x = Date, y = Wheat.Leaf.LAI)) +
  geom_line(data = sim.opt.s, aes(x = Date, y = Wheat.Leaf.LAI)) + 
  ggtitle("LAI")


## Biomass
ggplot() + 
  geom_point(data = obsWheat, aes(x = Date, y = Wheat.AboveGround.Wt)) +
  geom_line(data = sim.opt.s, aes(x = Date, y = Wheat.AboveGround.Wt)) + 
  ggtitle("Biomass (g/m2)")


