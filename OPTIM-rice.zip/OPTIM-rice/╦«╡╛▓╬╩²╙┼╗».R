rm(list = ls())
library(apsimx)
library(tidyverse)
library(BayesianTools)
library(rstantools)

############
# Classic
setwd('F:/APSIM工作文件夹/OPTIM')
wheat <- apsim('Wheat.apsim')
obsWh <- read.csv('F:/APSIM工作文件夹/OPTIM/ObsW.csv')%>%mutate(Date=as.Date(Date, 
                                                                        format = "%m/%d/%Y"))

ObsSim <- wheat%>%filter(Date%in%obsWh$Date)%>%
  select(Date,Stage,biomass,lai)%>%left_join(obsWh,.,by='Date')

ObsSim%>%ggplot(aes(x=lai.x,y=lai.y))+
  geom_point(size=2)+
  scale_x_continuous(limits = c(0,3.5))+
  scale_y_continuous(limits = c(0,3.5))+
  geom_smooth(method = 'lm',se = FALSE)+
  geom_abline(slope = 1,intercept = 0,size=1,linetype=2,color='grey')+
  coord_equal()+
  theme_bw()
  
ObsSim%>%ggplot(aes(x=biomass.x,y=biomass.y))+
  geom_point(size=2)+
  scale_x_continuous(limits = c(0,10000))+
  scale_y_continuous(limits = c(0,10000))+
  geom_smooth(method = 'lm',se = FALSE)+
  geom_abline(slope = 1,intercept = 0,size=1,linetype=2,color='grey')+
  coord_equal()+
  theme_bw()

ObsSim%>%ggplot(aes(x=Stage.x,y=Stage.y))+
  geom_point(size=2)+
  scale_x_continuous(limits = c(0,10))+
  scale_y_continuous(limits = c(0,10))+
  geom_smooth(method = 'lm',se = FALSE)+
  geom_abline(slope = 1,intercept = 0,size=1,linetype=2,color='grey')+
  coord_equal()+
  theme_bw()


RMSEFun=function(simvalue,obsvalue) {sqrt(mean((simvalue-obsvalue)^2))}
RRMSEFun=function(simvalue,obsvalue) {sqrt(mean((simvalue-obsvalue)^2))/mean(obsvalue)}
EFFun=function(simvalue,obsvalue){
  1-sum((simvalue-obsvalue)^2)/sum((obsvalue-mean(obsvalue))^2)
}
DvalueFun=function(simvalue,obsvalue){1-sum((simvalue-obsvalue)^2)/sum((abs(simvalue-mean(obsvalue))+abs(obsvalue-mean(simvalue)))^2)}
MBEFun=function(simvalue,obsvalue){mean(abs(simvalue-obsvalue))}
R2Fun=function(simvalue,obsvalue){summary(lm(simvalue~1+obsvalue))$r.squared}
R2Funadj=function(simvalue,obsvalue){summary(lm(simvalue~1+obsvalue))$adj.r.squared}

ObsSim%>%dplyr::summarise(
  RMSE.biomass=RMSEFun(biomass.y,biomass.x),
  RRMSE.biomass=RRMSEFun(biomass.y,biomass.x),
  Dvalue.biomass=DvalueFun(biomass.y,biomass.x),
  EF.biomass=EFFun(biomass.y,biomass.x),
  RMSE.lai=RMSEFun(lai.y,lai.x),
  RRMSE.lai=RRMSEFun(lai.y,lai.x),
  Dvalue.lai=DvalueFun(lai.y,lai.x),
  EF.lai=EFFun(lai.y,lai.x)
)






##单个参数调参####
ObjectFun <- function(par){
  tt_end_of_juvenile=as.character(par)
  edit_apsim_xml("Wheat.xml", 
                 src.dir = 'F:/APSIM工作文件夹/OPTIM',
                 wrt.dir = './New',
                 parm.path = ".//Model/xifeng24/tt_end_of_juvenile",
                 value = tt_end_of_juvenile)
  
  wheat <- apsim('Wheat2.apsim')
  
  ObsSim=wheat%>%filter(Date%in%obsWh$Date)%>%
    select(Date,Stage,biomass,lai)%>%left_join(obsWh,.,by='Date')%>%
    filter(lai.y>0)
  
  ModelRes <- RRMSEFun(ObsSim$Stage.y,ObsSim$Stage.x)
  return(ModelRes)
}

Parsopt <- optim(450, ObjectFun, method="Nelder-Mead")


ObjectFun(Parsopt$par)
edit_apsim_xml("Wheat.xml", 
               src.dir = 'F:/APSIM工作文件夹/OPTIM',
               wrt.dir = './New',
               parm.path = ".//Model/xifeng24/tt_end_of_juvenile",
               value = round(Parsopt$par)%>%as.character())

wheat2 <- apsim('Wheat2.apsim')

#Phe
ggplot() + 
  geom_point(data = obsWh, aes(x = Date, y = Stage)) +
  geom_line(data = wheat2, aes(x = Date, y = Stage)) + 
  ggtitle("Phenology")

## LAI
ggplot() + 
  geom_point(data = obsWh, aes(x = Date, y = lai)) +
  geom_line(data = wheat2, aes(x = Date, y = lai)) + 
  ggtitle("LAI")

## Biomass
ggplot() + 
  geom_point(data = obsWh, aes(x = Date, y = biomass)) +
  geom_line(data = wheat2, aes(x = Date, y = biomass)) + 
  ggtitle("Biomass (g/m2)")



ObsSim=wheat2%>%filter(Date%in%obsWh$Date)%>%
  select(Date,Stage,biomass,lai)%>%left_join(obsWh,.,by='Date')%>%
  filter(lai.y>0)

ObsSim%>%dplyr::summarise(
  RMSE.biomass=RMSEFun(biomass.y,biomass.x),
  RRMSE.biomass=RRMSEFun(biomass.y,biomass.x),
  Dvalue.biomass=DvalueFun(biomass.y,biomass.x),
  EF.biomass=EFFun(biomass.y,biomass.x),
  RMSE.lai=RMSEFun(lai.y,lai.x),
  RRMSE.lai=RRMSEFun(lai.y,lai.x),
  Dvalue.lai=DvalueFun(lai.y,lai.x),
  EF.lai=EFFun(lai.y,lai.x),
  RMSE.Stage=RMSEFun(Stage.y,Stage.x),
  RRMSE.Stage=RRMSEFun(Stage.y,Stage.x),
  Dvalue.Stage=DvalueFun(Stage.y,Stage.x),
  EF.Stage=EFFun(Stage.y,Stage.x)
)









####多个参数调参——针对物候期######
ObjectFun1 <- function(pars){
  tt_end_of_juvenile <- as.character(pars[1])
  edit_apsim_xml("Wheat.xml", 
                 src.dir = 'F:/APSIM工作文件夹/OPTIM',
                 wrt.dir = './New',
                 parm.path = ".//Model/xifeng24/tt_end_of_juvenile",
                 value = tt_end_of_juvenile)
  
  tt_floral_initiation=as.character(pars[2])
  edit_apsim_xml("Wheat-edited.xml", 
                 src.dir = './New',
                 wrt.dir = './New',
                 overwrite = TRUE,
                 parm.path = ".//Model/xifeng24/tt_floral_initiation",
                 value = tt_floral_initiation)
  
  tt_start_grain_fill=as.character(pars[3])
  edit_apsim_xml("Wheat-edited.xml", 
                 src.dir = './New',
                 wrt.dir = './New',
                 overwrite = TRUE,
                 parm.path = ".//Model/xifeng24/tt_start_grain_fill",
                 value = tt_start_grain_fill)
  
  tt_end_grain_fill=as.character(pars[4])
  edit_apsim_xml("Wheat-edited.xml", 
                 src.dir = './New',
                 wrt.dir = './New',
                 overwrite = TRUE,
                 parm.path = ".//Model/xifeng24/tt_end_grain_fill",
                 value = tt_end_grain_fill)
  
  startgf_to_mat=as.character(pars[5])
  edit_apsim_xml("Wheat-edited.xml", 
                 src.dir = './New',
                 wrt.dir = './New',
                 overwrite = TRUE,
                 parm.path = ".//Model/xifeng24/startgf_to_mat",
                 value = startgf_to_mat)
  
  wheat <- apsim('Wheat2.apsim')
  
  ObsSim <- wheat%>%filter(Date%in%obsWh$Date)%>%
    select(Date,Stage,biomass,lai)%>%left_join(obsWh,.,by='Date')%>%
    filter(lai.y>0)
  
  ModelRes=RRMSEFun(ObsSim$Stage.y,ObsSim$Stage.x)
  return(ModelRes)
}

Parsopt1 <- optim(c(500,550,600,30,500), ObjectFun1, method="Nelder-Mead")

Parsopt1$par
ObjectFun1(Parsopt1$par)

edit_apsim_xml("Wheat.xml", 
               src.dir = 'F:/APSIM工作文件夹/OPTIM',
               wrt.dir = './New',
               parm.path = ".//Model/xifeng24/tt_end_of_juvenile",
               value = round(Parsopt1$par[1])%>%as.character())


edit_apsim_xml("Wheat-edited.xml", 
               src.dir = './New',
               wrt.dir = './New',
               overwrite = TRUE,
               parm.path = ".//Model/xifeng24/tt_floral_initiation",
               value = round(Parsopt1$par[2])%>%as.character())

tt_start_grain_fill <- as.character(round(Parsopt1$par[3]))
edit_apsim_xml("Wheat-edited.xml", 
               src.dir = './New',
               wrt.dir = './New',
               overwrite = TRUE,
               parm.path = ".//Model/xifeng24/tt_start_grain_fill",
               value = tt_start_grain_fill)

tt_end_grain_fill <- as.character(round(Parsopt1$par[4]))
edit_apsim_xml("Wheat-edited.xml", 
               src.dir = './New',
               wrt.dir = './New',
               overwrite = TRUE,
               parm.path = ".//Model/xifeng24/tt_end_grain_fill",
               value = tt_end_grain_fill)

startgf_to_mat=as.character(round(Parsopt1$par[5]))
edit_apsim_xml("Wheat-edited.xml", 
               src.dir = './New',
               wrt.dir = './New',
               overwrite = TRUE,
               parm.path = ".//Model/xifeng24/startgf_to_mat",
               value = startgf_to_mat)






wheat3 <- apsim('Wheat2.apsim')

#Phe
ggplot() + 
  geom_point(data = obsWh, aes(x = Date, y = Stage)) +
  geom_line(data = wheat3, aes(x = Date, y = Stage)) + 
  ggtitle("Phenology")

## LAI
ggplot() + 
  geom_point(data = obsWh, aes(x = Date, y = lai)) +
  geom_line(data = wheat3, aes(x = Date, y = lai)) + 
  ggtitle("LAI")

## Biomass
ggplot() + 
  geom_point(data = obsWh, aes(x = Date, y = biomass)) +
  geom_line(data = wheat3, aes(x = Date, y = biomass)) + 
  ggtitle("Biomass (g/m2)")












####多个参数调参-针对生物量和产量######
ObjectFun2 <- function(pars){
  
  rue <- paste(c(0,0,rep(pars[1],6),0.00,0.00,0),collapse = "  ")
  edit_apsim_xml("Wheat-edited.xml", 
                 src.dir = './New',
                 wrt.dir = "./New",
                 overwrite = TRUE,
                 parm.path = ".//Model/plant/y_rue",
                 value = rue)
  
  
  
  wheat <- apsim('Wheat2.apsim')
  
  ObsSim <- wheat%>%filter(Date%in%obsWh$Date)%>%
    select(Date,Stage,biomass,lai)%>%left_join(obsWh,.,by='Date')%>%
    filter(lai.y>0)
  
  ModelRes <- RRMSEFun(ObsSim$biomass.y,ObsSim$biomass.x)
  return(ModelRes)
}

Parsopt2 <- optim(c(1.24), ObjectFun2, method="Nelder-Mead")

Parsopt2$par
ObjectFun2(Parsopt2$par)



rue <- paste(c(0,0,rep(round(Parsopt2$par[1],2),6),0.00,0.00,0),collapse = "  ")
edit_apsim_xml("Wheat-edited.xml", 
               src.dir = './New',
               wrt.dir = "./New",
               overwrite = TRUE,
               parm.path = ".//Model/plant/y_rue",
               value = rue)


wheat4 <- apsim('Wheat2.apsim')

ObsSim <- wheat4%>%filter(Date%in%obsWh$Date)%>%
  select(Date,Stage,biomass,lai)%>%left_join(obsWh,.,by='Date')%>%
  filter(lai.y>0)
ObsSim%>%dplyr::summarise(
  RMSE.biomass=RMSEFun(biomass.y,biomass.x),
  RRMSE.biomass=RRMSEFun(biomass.y,biomass.x),
  Dvalue.biomass=DvalueFun(biomass.y,biomass.x),
  EF.biomass=EFFun(biomass.y,biomass.x),
  RMSE.lai=RMSEFun(lai.y,lai.x),
  RRMSE.lai=RRMSEFun(lai.y,lai.x),
  Dvalue.lai=DvalueFun(lai.y,lai.x),
  EF.lai=EFFun(lai.y,lai.x),
  RMSE.Stage=RMSEFun(Stage.y,Stage.x),
  RRMSE.Stage=RRMSEFun(Stage.y,Stage.x),
  Dvalue.Stage=DvalueFun(Stage.y,Stage.x),
  EF.Stage=EFFun(Stage.y,Stage.x)
)


#Phe
ggplot() + 
  geom_point(data = obsWh, aes(x = Date, y = Stage)) +
  geom_line(data = wheat4, aes(x = Date, y = Stage)) + 
  ggtitle("Phenology")

## LAI
ggplot() + 
  geom_point(data = obsWh, aes(x = Date, y = lai)) +
  geom_line(data = wheat4, aes(x = Date, y = lai)) + 
  ggtitle("LAI")

## Biomass
ggplot() + 
  geom_point(data = obsWh, aes(x = Date, y = biomass)) +
  geom_line(data = wheat4, aes(x = Date, y = biomass)) + 
  ggtitle("Biomass (g/m2)")



ObsSim%>%ggplot(aes(x=lai.x,y=lai.y))+
  geom_point(size=2)+
  scale_x_continuous(limits = c(0,3.5))+
  scale_y_continuous(limits = c(0,3.5))+
  geom_smooth(method = 'lm',se = FALSE)+
  geom_abline(slope = 1,intercept = 0,size=1,linetype=2,color='grey')+
  coord_equal()+
  theme_bw()

ObsSim%>%ggplot(aes(x=biomass.x,y=biomass.y))+
  geom_point(size=2)+
  scale_x_continuous(limits = c(0,10000))+
  scale_y_continuous(limits = c(0,10000))+
  geom_smooth(method = 'lm',se = FALSE)+
  geom_abline(slope = 1,intercept = 0,size=1,linetype=2,color='grey')+
  coord_equal()+
  theme_bw()

ObsSim%>%ggplot(aes(x=Stage.x,y=Stage.y))+
  geom_point(size=2)+
  scale_x_continuous(limits = c(4,10))+
  scale_y_continuous(limits = c(4,10))+
  geom_smooth(method = 'lm',se = FALSE)+
  geom_abline(slope = 1,intercept = 0,size=1,linetype=2,color='grey')+
  coord_equal()+
  theme_bw()











#########################################









burnIn=10
par(mfrow = c(2,3))
hist(chain[-(1:burnIn),1],nclass=30,  main="Posterior of par1", xlab="True value = red line" )
abline(v = mean(chain[-(1:burnIn),1]))
abline(v = par[1], col="red" )
hist(chain[-(1:burnIn),2],nclass=30, main="Posterior of par2", xlab="True value = red line")
abline(v = mean(chain[-(1:burnIn),2]))
abline(v = par[2], col="red" )
hist(chain[-(1:burnIn),3],nclass=30, main="Posterior of par3", xlab="True value = red line")
abline(v = mean(chain[-(1:burnIn),3]) )
abline(v = par[3], col="red" )
plot(chain[-(1:burnIn),1], type = "l", xlab="True value = red line" , main = "Chain values of par1")
abline(h = par[1], col="red" )
plot(chain[-(1:burnIn),2], type = "l", xlab="True value = red line" , main = "Chain values of par2" )
abline(h = par[2], col="red" )
plot(chain[-(1:burnIn),3], type = "l", xlab="True value = red line" , main = "Chain values of par3")
abline(h = par[3], col="red" )

par1=mean(chain[-(1:burnIn),1])
par2=mean(chain[-(1:burnIn),2])

edit_apsim_xml("Wheat.xml", 
               src.dir = 'E:/APSIM/OPTIM',
               wrt.dir = './New',
               parm.path = ".//Model/xifeng24/tt_end_of_juvenile",
               value = par1%>%as.character())
rue <- paste(c(0,0,rep(par2,6),0.00,0.00,0),collapse = "  ")
edit_apsim_xml("Wheat-edited.xml", 
               src.dir = './New',
               wrt.dir = './New',
               parm.path = ".//Model/plant/y_rue",
               edit.tag ='',
               value = rue)
wheat=apsim('Wheat2.apsim')
wheat=apsim('Wheat.apsim')
ObsSim=wheat%>%filter(Date%in%obsWh$Date)%>%
  select(Date,Stage,biomass,lai)%>%left_join(obsWh,.,by='Date')

## Biomass
ggplot() + 
  geom_point(data = obsWh, aes(x = Date, y = biomass)) +
  geom_line(data = wheat, aes(x = Date, y = biomass)) + 
  ggtitle("Biomass (g/m2)")




